-- HOME EMOM v13: 1v1 duels. Run once in Supabase > SQL Editor > Run.
-- Safe to run again (uses "if not exists" / "create or replace").

create table if not exists public.duels (
  id bigserial primary key,
  a uuid not null references public.profiles(id) on delete cascade,
  b uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','active','declined','cancelled')),
  by_admin boolean not null default false,
  start_day date,
  end_day date,
  created_at timestamptz not null default now(),
  check (a <> b)
);
create index if not exists duels_a_idx on public.duels(a);
create index if not exists duels_b_idx on public.duels(b);
alter table public.duels enable row level security;   -- no policies: only the functions below can touch it

-- ---------- helpers (not callable from the app) ----------
create or replace function public._duel_uid(p_token uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare u uuid;
begin
  select user_id into u from sessions where token = p_token;
  if u is null then raise exception 'bad_session'; end if;
  return u;
end $$;

create or replace function public._duel_today() returns date
language sql stable as $$ select (now() at time zone 'Africa/Dar_es_Salaam')::date $$;

create or replace function public._duel_busy(p_user uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists(select 1 from duels d
    where d.status = 'active' and d.end_day >= _duel_today() and p_user in (d.a, d.b))
$$;

create or replace function public._duel_score(p_user uuid, p_from date, p_to date) returns json
language sql stable security definer set search_path = public as $$
  select json_build_object('points', coalesce(sum(points),0)::int, 'workouts', count(*)::int, 'mins', coalesce(sum(mins),0)::int)
  from workouts where user_id = p_user and day between p_from and p_to
$$;

create or replace function public._duel_json(d duels, p_me uuid) returns json
language plpgsql stable security definer set search_path = public as $$
declare
  t date := _duel_today();
  na text; nb text; sa json; sb json;
  pa int; pb int; wa int; wb int; ma int; mb int;
  fin boolean; win text := null;
begin
  select name into na from profiles where id = d.a;
  select name into nb from profiles where id = d.b;
  sa := _duel_score(d.a, d.start_day, d.end_day);
  sb := _duel_score(d.b, d.start_day, d.end_day);
  pa := (sa->>'points')::int; wa := (sa->>'workouts')::int; ma := (sa->>'mins')::int;
  pb := (sb->>'points')::int; wb := (sb->>'workouts')::int; mb := (sb->>'mins')::int;
  fin := d.end_day < t;
  if fin then
    -- winner: points, then workouts, then minutes; all equal = tie
    if row(pa,wa,ma) > row(pb,wb,mb) then win := 'a';
    elsif row(pa,wa,ma) < row(pb,wb,mb) then win := 'b';
    else win := 'tie'; end if;
  end if;
  return json_build_object(
    'id', d.id, 'by_admin', d.by_admin, 'start_day', d.start_day, 'end_day', d.end_day,
    'finished', fin, 'winner', win,
    'days_left', case when fin then 0 else d.end_day - t + 1 end,
    'starts_in', case when d.start_day > t then d.start_day - t else 0 end,
    'me', case when d.a = p_me then 'a' when d.b = p_me then 'b' else null end,
    'a', json_build_object('id', d.a, 'name', na, 'points', pa, 'workouts', wa, 'mins', ma),
    'b', json_build_object('id', d.b, 'name', nb, 'points', pb, 'workouts', wb, 'mins', mb)
  );
end $$;

revoke all on function public._duel_uid(uuid) from public, anon, authenticated;
revoke all on function public._duel_today() from public, anon, authenticated;
revoke all on function public._duel_busy(uuid) from public, anon, authenticated;
revoke all on function public._duel_score(uuid, date, date) from public, anon, authenticated;
revoke all on function public._duel_json(duels, uuid) from public, anon, authenticated;

-- ---------- functions the app calls ----------

-- people I can challenge (same gender; admin sees everyone except admins)
create or replace function public.duel_users(p_token uuid) returns json
language plpgsql security definer set search_path = public as $$
declare me uuid := _duel_uid(p_token); mp profiles; mon date;
begin
  select * into mp from profiles where id = me;
  mon := _duel_today() - (extract(isodow from _duel_today())::int - 1);
  return coalesce((select json_agg(x order by x.name) from (
    select p.id, p.name, p.gender, _duel_busy(p.id) as busy,
      coalesce((select sum(w.points) from workouts w where w.user_id = p.id and w.day >= mon), 0)::int as week_points
    from profiles p
    where p.id <> me and not coalesce(p.is_admin, false) and (coalesce(mp.is_admin, false) or p.gender = mp.gender)
  ) x), '[]'::json);
end $$;

-- my current 1v1, invites for me, my own pending invite, my latest finished 1v1
create or replace function public.duel_mine(p_token uuid) returns json
language plpgsql security definer set search_path = public as $$
declare me uuid := _duel_uid(p_token); t date := _duel_today(); da duels; dl duels; res json;
begin
  select * into da from duels where status = 'active' and end_day >= t and me in (a, b) order by id desc limit 1;
  select * into dl from duels where status = 'active' and end_day < t and me in (a, b) order by end_day desc, id desc limit 1;
  res := json_build_object(
    'busy', da.id is not null,
    'active', case when da.id is not null then _duel_json(da, me) else null end,
    'last', case when dl.id is not null then _duel_json(dl, me) else null end,
    'incoming', coalesce((select json_agg(json_build_object('id', d.id, 'from_id', d.a, 'from_name', p.name) order by d.id)
        from duels d join profiles p on p.id = d.a
        where d.status = 'pending' and d.b = me and d.created_at > now() - interval '3 days'), '[]'::json),
    'outgoing', (select json_build_object('id', d.id, 'to_id', d.b, 'to_name', p.name)
        from duels d join profiles p on p.id = d.b
        where d.status = 'pending' and d.a = me and d.created_at > now() - interval '3 days'
        order by d.id desc limit 1)
  );
  return res;
end $$;

-- every ongoing 1v1 (visible to all signed-in users)
create or replace function public.duel_live(p_token uuid) returns json
language plpgsql security definer set search_path = public as $$
declare me uuid := _duel_uid(p_token);
begin
  return coalesce((select json_agg(_duel_json(d, me) order by d.id)
    from duels d where d.status = 'active' and d.end_day >= _duel_today()), '[]'::json);
end $$;

-- send a challenge (replaces my earlier pending challenge)
create or replace function public.duel_challenge(p_token uuid, p_opp uuid) returns json
language plpgsql security definer set search_path = public as $$
declare me uuid := _duel_uid(p_token); mp profiles; op profiles;
begin
  select * into mp from profiles where id = me;
  select * into op from profiles where id = p_opp;
  if op.id is null or op.id = me or coalesce(op.is_admin, false) or op.gender is distinct from mp.gender then raise exception 'bad_opponent'; end if;
  if _duel_busy(me) then raise exception 'busy_you'; end if;
  if _duel_busy(p_opp) then raise exception 'busy_them'; end if;
  update duels set status = 'cancelled' where a = me and status = 'pending';
  insert into duels(a, b, status) values (me, p_opp, 'pending');
  return json_build_object('ok', true);
end $$;

-- accept or decline an invite
create or replace function public.duel_respond(p_token uuid, p_duel bigint, p_accept boolean) returns json
language plpgsql security definer set search_path = public as $$
declare me uuid := _duel_uid(p_token); d duels; t date := _duel_today(); s date;
begin
  select * into d from duels where id = p_duel and b = me and status = 'pending' and created_at > now() - interval '3 days';
  if d.id is null then raise exception 'not_found'; end if;
  if not p_accept then
    update duels set status = 'declined' where id = d.id;
    return json_build_object('ok', true);
  end if;
  if _duel_busy(me) then raise exception 'busy_you'; end if;
  if _duel_busy(d.a) then
    update duels set status = 'cancelled' where id = d.id;
    raise exception 'busy_them';
  end if;
  s := case when extract(isodow from t)::int = 7 then t + 1 else t end;   -- Sunday: starts Monday
  update duels set status = 'active', start_day = s, end_day = s + (7 - extract(isodow from s)::int) where id = d.id;
  update duels set status = 'cancelled' where status = 'pending' and id <> d.id and (a in (me, d.a) or b in (me, d.a));
  return json_build_object('ok', true);
end $$;

-- cancel my own pending challenge
create or replace function public.duel_cancel(p_token uuid, p_duel bigint) returns json
language plpgsql security definer set search_path = public as $$
declare me uuid := _duel_uid(p_token);
begin
  update duels set status = 'cancelled' where id = p_duel and a = me and status = 'pending';
  return json_build_object('ok', true);
end $$;

-- admin: pair two people directly
create or replace function public.admin_duel_pair(p_token uuid, p_a uuid, p_b uuid) returns json
language plpgsql security definer set search_path = public as $$
declare me uuid := _duel_uid(p_token); pa profiles; pb profiles; t date := _duel_today(); s date;
begin
  if not coalesce((select is_admin from profiles where id = me), false) then raise exception 'not_admin'; end if;
  select * into pa from profiles where id = p_a;
  select * into pb from profiles where id = p_b;
  if pa.id is null or pb.id is null or pa.id = pb.id or coalesce(pa.is_admin, false) or coalesce(pb.is_admin, false) or pa.gender is distinct from pb.gender then raise exception 'bad_opponent'; end if;
  if _duel_busy(p_a) or _duel_busy(p_b) then raise exception 'busy_them'; end if;
  s := case when extract(isodow from t)::int = 7 then t + 1 else t end;
  update duels set status = 'cancelled' where status = 'pending' and (a in (p_a, p_b) or b in (p_a, p_b));
  insert into duels(a, b, status, by_admin, start_day, end_day)
    values (p_a, p_b, 'active', true, s, s + (7 - extract(isodow from s)::int));
  return json_build_object('ok', true);
end $$;

-- admin: cancel a running 1v1
create or replace function public.admin_duel_cancel(p_token uuid, p_duel bigint) returns json
language plpgsql security definer set search_path = public as $$
declare me uuid := _duel_uid(p_token);
begin
  if not coalesce((select is_admin from profiles where id = me), false) then raise exception 'not_admin'; end if;
  update duels set status = 'cancelled' where id = p_duel and status in ('pending', 'active');
  return json_build_object('ok', true);
end $$;

grant execute on function public.duel_users(uuid), public.duel_mine(uuid), public.duel_live(uuid),
  public.duel_challenge(uuid, uuid), public.duel_respond(uuid, bigint, boolean), public.duel_cancel(uuid, bigint),
  public.admin_duel_pair(uuid, uuid, uuid), public.admin_duel_cancel(uuid, bigint) to anon, authenticated;
